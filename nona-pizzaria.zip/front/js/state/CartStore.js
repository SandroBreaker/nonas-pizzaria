// js/state/CartStore.js

import { CART_STORAGE_KEY, CATEGORIES } from './constants.js';
import { renderApp } from '../app.js'; 

export const CartStore = {
  items: [],
  isCartOpen: false,
  
  updateUI() {
    renderApp(true); 
  },

  init() {
    const stored = localStorage.getItem(CART_STORAGE_KEY);
    if (stored) {
      try {
        this.items = JSON.parse(stored);
      } catch (e) {
        console.error("Failed to parse cart storage", e);
        this.items = [];
      }
    }
    this.updateUI(); 
    
    window.addEventListener('storage', (e) => {
        if (e.key === CART_STORAGE_KEY) {
            this.loadFromStorage();
        }
    });
  },

  loadFromStorage() {
    const stored = localStorage.getItem(CART_STORAGE_KEY);
    this.items = stored ? JSON.parse(stored) : [];
    this.updateUI();
  },

  saveAndRender() {
    localStorage.setItem(CART_STORAGE_KEY, JSON.stringify(this.items));
    this.updateUI();
  },

  get cartTotal() {
    return this.items.reduce((acc, item) => acc + item.totalPrice, 0);
  },

  get itemsCount() {
    return this.items.reduce((acc, item) => acc + item.quantity, 0);
  },

  addItem(product, size) {
    const isPizza = product.category === CATEGORIES.PIZZA;
    const finalPrice =
      isPizza && size && product.priceModifiers
        ? product.priceModifiers[size] || product.basePrice
        : product.basePrice;

    const existingItemIndex = this.items.findIndex(
      (item) => item.product.id === product.id && item.size === size
    );

    if (existingItemIndex > -1) {
      const item = this.items[existingItemIndex];
      item.quantity += 1;
      item.totalPrice = item.quantity * finalPrice;
    } else {
      const newItem = {
        cartId: `${product.id}-${size || 'default'}-${Date.now()}`,
        product,
        size,
        quantity: 1,
        totalPrice: finalPrice,
      };
      this.items.push(newItem);
    }

    this.isCartOpen = true; 
    this.saveAndRender();
  },

  removeItem(cartId) {
    this.items = this.items.filter((item) => item.cartId !== cartId);
    this.saveAndRender();
  },

  updateQuantity(cartId, delta) {
    this.items = this.items.map((item) => {
      if (item.cartId === cartId) {
        const newQuantity = Math.max(1, item.quantity + delta);
        const unitPrice = item.totalPrice / item.quantity;
        return {
          ...item,
          quantity: newQuantity,
          totalPrice: unitPrice * newQuantity,
        };
      }
      return item;
    });
    this.saveAndRender();
  },
  
  clearCart() {
    this.items = [];
    this.saveAndRender();
  }
};
