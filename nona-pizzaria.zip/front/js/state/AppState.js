// js/state/AppState.js

import { APP_VIEWS, CATEGORIES } from './constants.js';
import { renderApp } from '../app.js';

export const appState = {
  currentView: APP_VIEWS.MENU,
  selectedCategory: CATEGORIES.PIZZA,
  customerData: null, // Armazena os dados do cliente após o checkout
};

export function navigate(view) {
  appState.currentView = view;
  if (view === APP_VIEWS.MENU) {
      appState.selectedCategory = CATEGORIES.PIZZA;
  }
  renderApp();
}

export function setSelectedCategory(category) {
    appState.selectedCategory = category;
    renderApp();
}

// Salva os dados do formulário no estado
export function setCustomerData(data) {
    appState.customerData = data;
}
