// js/utils/helpers.js

/**
 * Formata um valor numérico para a moeda brasileira (BRL).
 * @param {number} value O valor a ser formatado.
 * @returns {string} O valor formatado como "R$ X.XXX,XX".
 */
export function formatCurrency(value) {
  return new Intl.NumberFormat('pt-BR', {
    style: 'currency',
    currency: 'BRL',
  }).format(value);
}

/**
 * Retorna o SVG de um ícone da biblioteca Lucide.
 * @param {string} iconName O nome do ícone (ex: 'ShoppingCart').
 * @param {string} className Classes CSS adicionais para o SVG.
 * @returns {string} O SVG do ícone como string.
 */
export function getIconSVG(iconName, className = '') {
  // Lucide Icons são globais, garantimos que lucide esteja disponível
  if (typeof lucide === 'undefined' || !lucide.icons[iconName]) {
    console.warn(`Ícone "${iconName}" não encontrado.`);
    return `<svg class="${className}" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><line x1="15" y1="9" x2="9" y2="15"></line><line x1="9" y1="9" x2="15" y2="15"></line></svg>`; // Ícone de erro ou placeholder
  }
  const icon = lucide.icons[iconName];
  return icon ? icon.toSvg({ class: className }) : '';
}

/**
 * Formata um número de telefone para (XX) XXXXX-XXXX.
 * @param {string} value O número de telefone.
 * @returns {string} O número formatado.
 */
export function maskPhone(value) {
  if (!value) return '';
  value = value.replace(/\D/g, ''); // Remove tudo que não for dígito
  value = value.replace(/^(\d{2})(\d)/g, '($1) $2'); // Adiciona parênteses
  value = value.replace(/(\d)(\d{4})$/, '$1-$2');    // Adiciona hífen
  return value;
}

/**
 * Valida um número de telefone no formato (XX) XXXXX-XXXX ou (XX) XXXX-XXXX.
 * @param {string} phone O número de telefone formatado.
 * @returns {boolean} True se for um telefone válido, False caso contrário.
 */
export function isValidPhone(phone) {
  // Regex para (XX) XXXXX-XXXX ou (XX) XXXX-XXXX
  const regex = /^\(\d{2}\)\s\d{4,5}-\d{4}$/;
  return regex.test(phone);
}


/**
 * Formata um CPF para 000.000.000-00.
 * @param {string} value O CPF.
 * @returns {string} O CPF formatado.
 */
export function maskCPF(value) {
  if (!value) return '';
  value = value.replace(/\D/g, ''); // Remove tudo que não for dígito
  value = value.replace(/(\d{3})(\d)/, '$1.$2');
  value = value.replace(/(\d{3})(\d)/, '$1.$2');
  value = value.replace(/(\d{3})(\d{1,2})$/, '$1-$2');
  return value;
}

/**
 * Valida um CPF.
 * @param {string} cpf O CPF formatado (000.000.000-00) ou não.
 * @returns {boolean} True se for um CPF válido, False caso contrário.
 */
export function isValidCPF(cpf) {
  if (!cpf) return false;
  cpf = cpf.replace(/[^\d]+/g, ''); // Remove caracteres não numéricos
  if (cpf.length !== 11 || /^(\d)\1{10}$/.test(cpf)) return false; // Verifica 11 dígitos e CPFs com todos os dígitos iguais
  
  let sum = 0;
  let remainder;

  for (let i = 1; i <= 9; i++) sum = sum + parseInt(cpf.substring(i - 1, i)) * (11 - i);
  remainder = (sum * 10) % 11;

  if ((remainder === 10) || (remainder === 11)) remainder = 0;
  if (remainder !== parseInt(cpf.substring(9, 10))) return false;

  sum = 0;
  for (let i = 1; i <= 10; i++) sum = sum + parseInt(cpf.substring(i - 1, i)) * (12 - i);
  remainder = (sum * 10) % 11;

  if ((remainder === 10) || (remainder === 11)) remainder = 0;
  if (remainder !== parseInt(cpf.substring(10, 11))) return false;

  return true;
}

/**
 * Formata um CEP para 00000-000.
 * @param {string} value O CEP.
 * @returns {string} O CEP formatado.
 */
export function maskZip(value) {
  if (!value) return '';
  value = value.replace(/\D/g, ''); // Remove tudo que não for dígito
  value = value.replace(/^(\d{5})(\d)/, '$1-$2');
  return value;
}

/**
 * Busca um endereço completo a partir de um CEP.
 * @param {string} zipCode O CEP a ser pesquisado (apenas dígitos).
 * @returns {Promise<{street: string, neighborhood: string} | null>} O endereço ou null em caso de erro.
 */
export async function fetchAddressByZipCode(zipCode) {
    const cleanZip = zipCode.replace(/\D/g, '');
    if (cleanZip.length !== 8) return null;

    try {
        const response = await fetch(`https://viacep.com.br/ws/${cleanZip}/json/`);
        const data = await response.json();
        if (data.erro) {
            console.error("CEP não encontrado.");
            return null;
        }
        return {
            street: data.logradouro,
            neighborhood: data.bairro,
            city: data.localidade,
            state: data.uf
        };
    } catch (error) {
        console.error("Erro ao buscar CEP:", error);
        return null;
    }
}

/**
 * Formata uma string de data para um formato legível (ex: "há 2 dias", "20 de Março de 2024").
 * @param {string} dateString A string de data no formato ISO (e.g., "2024-03-20T10:00:00Z").
 * @returns {string} A data formatada.
 */
export function formatDate(dateString) {
  const date = new Date(dateString);
  const now = new Date();
  const diffTime = Math.abs(now.getTime() - date.getTime());
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

  if (diffDays <= 7) {
    if (diffDays === 0) return "hoje";
    if (diffDays === 1) return "ontem";
    return `há ${diffDays} dias`;
  } else {
    return new Intl.DateTimeFormat('pt-BR', { day: 'numeric', month: 'long', year: 'numeric' }).format(date);
  }
}
