// js/utils/invictusPayApi.js

import { API_INVICTUS_ENDPOINT, API_INVICTUS_TOKEN } from '../state/constants.js';

/**
 * Executa a chamada para a API da Invictus Pay para gerar a transação PIX.
 * @param {object} payload Payload da transação (amount, customer, cart, etc.)
 * @returns {Promise<{success: boolean, data?: object, error?: string}>} Objeto de resposta
 */
export async function executeInvictusApi(payload) {
    const path = '/public/v1/transactions';
    const method = 'POST';

    try {
        const response = await fetch(`${API_INVICTUS_ENDPOINT}${path}?api_token=${API_INVICTUS_TOKEN}`, {
            method: method,
            headers: { 'Accept': 'application/json', 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });

        const data = await response.json();

        if (response.ok) {
            // Validação mínima se a resposta contém os dados de PIX
            if (data.payment_method === 'pix' && data.pix && data.pix.pix_qr_code) {
                return { success: true, data: data };
            } else {
                return { success: false, error: "A API não retornou dados de PIX válidos." };
            }
        } else {
            console.error("Erro API Invictus:", data);
            const errorMsg = data.errors ? Object.values(data.errors).flat().join('; ') : (data.message || "Dados inválidos.");
            return { success: false, error: `Erro na API: ${errorMsg}` };
        }

    } catch (error) {
        console.error("Erro de comunicação com o sistema de pagamento:", error);
        return { success: false, error: "Erro de comunicação com o sistema de pagamento." };
    }
}
