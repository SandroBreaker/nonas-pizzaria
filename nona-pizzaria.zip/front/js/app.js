// js/app.js - Main Controller e Inicialização

import { CartStore } from './state/CartStore.js';
import { appState } from './state/AppState.js';
import { renderHeader } from './components/Header.js';
import { renderCartDrawer } from './components/CartDrawer.js';
import { renderMenu } from './components/Menu.js';
import { renderCheckoutForm } from './components/CheckoutForm.js';
import { renderPixPayment } from './components/PixPayment.js';
import { APP_VIEWS } from './state/constants.js';

/**
 * Lógica de Navegação e Renderização Principal (Controller)
 * Orquestra qual componente principal (Menu, Checkout, Success) deve ser exibido.
 * * @param {boolean} onlyCartUpdate Se true, re-renderiza apenas o Header e o Drawer (otimização)
 */
export function renderApp(onlyCartUpdate = false) {
  const root = document.getElementById('root');
  
  // 1. Renderiza o Header (sempre visível)
  renderHeader();
  
  // 2. Renderiza o CartDrawer (overlay)
  renderCartDrawer();

  // Se for apenas uma atualização do carrinho, não precisamos redesenhar o conteúdo principal
  if (onlyCartUpdate) return;
  
  // 3. Remove o conteúdo anterior (main)
  let mainContent = root.querySelector('main');
  if (mainContent) {
    root.removeChild(mainContent);
  }
  
  // 4. Renderiza o novo conteúdo (main) baseado na View
  let newContent;
  switch (appState.currentView) {
    case APP_VIEWS.CHECKOUT:
      newContent = renderCheckoutForm();
      break;
    case APP_VIEWS.SUCCESS:
      newContent = renderPixPayment();
      break;
    case APP_VIEWS.MENU:
    default:
      newContent = renderMenu();
      break;
  }

  // Insere o novo conteúdo antes do Cart Drawer (que é fixo/overlay)
  let cartDrawer = root.querySelector('#cart-drawer');
  if (cartDrawer) {
    root.insertBefore(newContent, cartDrawer);
  } else {
    root.appendChild(newContent);
  }
}

// --- Inicialização da Aplicação ---
document.addEventListener('DOMContentLoaded', () => {
  CartStore.init(); // Inicia o estado do carrinho e persistência
  renderApp();      // Renderiza a primeira tela (MENU)
});
