// js/components/CheckoutForm.js

import { navigate, setCustomerData } from '../state/AppState.js'; // IMPORT ATUALIZADO
import { APP_VIEWS } from '../state/constants.js';
import { getIconSVG, maskCPF, maskPhone, maskZip, isValidCPF, isValidPhone, fetchAddressByZipCode } from '../utils/helpers.js';

export function renderCheckoutForm() {
  const root = document.getElementById('root');
  const main = document.createElement('main');
  main.className = 'container mx-auto';

  let formData = {
    fullName: '', email: '', phone: '', cpf: '',
    address: { zipCode: '', street: '', number: '', neighborhood: '', complement: '' }
  };
  let errors = {};

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    let formattedValue = value;

    if (name === 'cpf') formattedValue = maskCPF(value);
    if (name === 'phone') formattedValue = maskPhone(value);
    if (name === 'zipCode') formattedValue = maskZip(value);

    // 1. Atualiza o formData
    if (name in formData.address) {
      formData.address[name] = formattedValue;
    } else {
      formData[name] = formattedValue;
    }
    
    // Clear error on change
    if (errors[name]) {
        errors[name] = '';
    }
    
    // 2. Lógica de Autocompletar CEP
    if (name === 'zipCode' && formData.address.zipCode.replace(/[^\d]/g, '').length === 8) {
        clearTimeout(window.zipTimeout);
        window.zipTimeout = setTimeout(async () => {
            const address = await fetchAddressByZipCode(formData.address.zipCode);
            if (address) {
                formData.address.street = formData.address.street || address.street;
                formData.address.neighborhood = formData.address.neighborhood || address.neighborhood;
                
                renderFormContent(main);
                
                const numberInput = main.querySelector('input[name="number"]');
                if(numberInput) numberInput.focus();
            }
        }, 300);
    }
  };
  
  const validateForm = () => {
    errors = {};
    if (!formData.fullName.trim()) errors.fullName = "Nome é obrigatório";
    if (!formData.email.includes('@')) errors.email = "Email inválido";
    if (!isValidPhone(formData.phone)) errors.phone = "Telefone inválido";
    if (!isValidCPF(formData.cpf)) errors.cpf = "CPF inválido";
    
    // Validação de Endereço combinada
    if (formData.address.street.length < 3) errors.address = "Rua é obrigatória";
    if (formData.address.zipCode.replace(/[^\d]/g, '').length !== 8) errors.address = "CEP inválido";
    if (!formData.address.number) errors.address = "Número é obrigatório";
    if (!formData.address.neighborhood) errors.address = "Bairro é obrigatório";

    return Object.keys(errors).length === 0;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (validateForm()) {
      setCustomerData(formData); // Ação CORRIGIDA: Salva dados reais
      navigate(APP_VIEWS.SUCCESS);
    } else {
      renderFormContent(main);
    }
  };
  
  const renderFormContent = (container) => {
    container.innerHTML = `
      <div class="max-w-2xl mx-auto py-8 px-4 animate-in fade-in slide-in-from-bottom-4 duration-500">
        <button 
          id="back-to-menu-btn"
          class="flex items-center text-stone-500 hover-text-dark mb-6 transition-colors"
        >
          ${getIconSVG('ChevronLeft', 'icon-20')}
          Voltar para o Menu
        </button>

        <div class="bg-white rounded-2xl shadow-xl border border-stone-100 overflow-hidden">
          <div class="bg-stone-50 p-6 border-b border-stone-100">
            <h2 class="text-2xl font-serif font-bold text-dark">Checkout</h2>
            <p class="text-stone-500">Complete seus dados para finalizar o pedido.</p>
          </div>

          <form id="checkout-form" class="p-6 space-y-8">
            <section>
              <h3 class="flex items-center gap-2 font-bold text-dark mb-4">
                ${getIconSVG('User', 'icon-20 text-primary')} Dados Pessoais
              </h3>
              <div class="grid grid-cols-1 md-grid-cols-2 gap-4">
                <div class="md-col-span-2">
                  <label class="block text-sm font-medium text-stone-700 mb-1">Nome Completo</label>
                  <input
                    type="text"
                    required
                    name="fullName"
                    value="${formData.fullName}"
                    placeholder="João Silva"
                    class="w-full px-4 py-2 rounded-lg border border-stone-200 focus-ring-2 focus-border-primary transition-all outline-none"
                  />
                  ${errors.fullName ? `<span class="text-xs text-red-500 mt-1">${errors.fullName}</span>` : ''}
                </div>
                
                <div>
                  <label class="block text-sm font-medium text-stone-700 mb-1">CPF</label>
                  <input
                    type="text"
                    required
                    maxlength="14"
                    name="cpf"
                    value="${formData.cpf}"
                    placeholder="000.000.000-00"
                    class="w-full px-4 py-2 rounded-lg border ${errors.cpf ? 'input-error' : 'border-stone-200'} focus-ring-2 focus-border-primary transition-all outline-none"
                  />
                  ${errors.cpf ? `<span class="text-xs text-red-500 mt-1">${errors.cpf}</span>` : ''}
                </div>

                <div>
                  <label class="block text-sm font-medium text-stone-700 mb-1">Telefone / WhatsApp</label>
                  <input
                    type="tel"
                    required
                    maxlength="15"
                    name="phone"
                    value="${formData.phone}"
                    placeholder="(11) 99999-9999"
                    class="w-full px-4 py-2 rounded-lg border ${errors.phone ? 'input-error' : 'border-stone-200'} focus-ring-2 focus-border-primary transition-all outline-none"
                  />
                  ${errors.phone ? `<span class="text-xs text-red-500 mt-1">${errors.phone}</span>` : ''}
                </div>

                <div class="md-col-span-2">
                  <label class="block text-sm font-medium text-stone-700 mb-1">Email</label>
                  <input
                    type="email"
                    required
                    name="email"
                    value="${formData.email}"
                    placeholder="joao@exemplo.com"
                    class="w-full px-4 py-2 rounded-lg border border-stone-200 focus-ring-2 focus-border-primary transition-all outline-none"
                  />
                  ${errors.email ? `<span class="text-xs text-red-500 mt-1">${errors.email}</span>` : ''}
                </div>
              </div>
            </section>

            <section>
              <h3 class="flex items-center gap-2 font-bold text-dark mb-4">
                ${getIconSVG('MapPin', 'icon-20 text-primary')} Entrega
              </h3>
              <div class="grid grid-cols-1 md-grid-cols-4 gap-4">
                <div class="md-col-span-1">
                  <label class="block text-sm font-medium text-stone-700 mb-1">CEP</label>
                  <input
                    type="text"
                    required
                    maxlength="9"
                    name="zipCode"
                    value="${formData.address.zipCode}"
                    placeholder="00000-000"
                    class="w-full px-4 py-2 rounded-lg border border-stone-200 focus-ring-2 focus-border-primary transition-all outline-none"
                  />
                </div>
                <div class="md-col-span-3">
                  <label class="block text-sm font-medium text-stone-700 mb-1">Rua</label>
                  <input
                    type="text"
                    required
                    name="street"
                    value="${formData.address.street}"
                    class="w-full px-4 py-2 rounded-lg border border-stone-200 focus-ring-2 focus-border-primary transition-all outline-none"
                  />
                </div>
                <div class="md-col-span-1">
                  <label class="block text-sm font-medium text-stone-700 mb-1">Número</label>
                  <input
                    type="text"
                    required
                    name="number"
                    value="${formData.address.number}"
                    class="w-full px-4 py-2 rounded-lg border border-stone-200 focus-ring-2 focus-border-primary transition-all outline-none"
                  />
                </div>
                <div class="md-col-span-2">
                  <label class="block text-sm font-medium text-stone-700 mb-1">Bairro</label>
                  <input
                    type="text"
                    required
                    name="neighborhood"
                    value="${formData.address.neighborhood}"
                    class="w-full px-4 py-2 rounded-lg border border-stone-200 focus-ring-2 focus-border-primary transition-all outline-none"
                  />
                </div>
                <div class="md-col-span-1">
                  <label class="block text-sm font-medium text-stone-700 mb-1">Comp.</label>
                  <input
                    type="text"
                    name="complement"
                    value="${formData.address.complement}"
                    class="w-full px-4 py-2 rounded-lg border border-stone-200 focus-ring-2 focus-border-primary transition-all outline-none"
                  />
                </div>
                ${errors.address ? `<div class="md-col-span-4 text-xs text-red-500">${errors.address}</div>` : ''}
              </div>
            </section>

            <div class="pt-6 border-t border-stone-100">
              <button 
                type="submit"
                class="w-full bg-primary hover-bg-red-700 text-white text-lg font-bold py-4 rounded-xl shadow-lg shadow-red-200 transition-all transform active-scale-99 flex items-center justify-center gap-2"
              >
                ${getIconSVG('CreditCard', 'icon-24')}
                Ir para Pagamento
              </button>
            </div>
          </form>
        </div>
      </div>
    `;
    
    container.querySelector('#back-to-menu-btn').addEventListener('click', () => navigate(APP_VIEWS.MENU));
    const form = container.querySelector('#checkout-form');
    form.addEventListener('submit', handleSubmit);
    
    form.querySelectorAll('input').forEach(input => {
        input.addEventListener('input', handleInputChange);
    });
    
    lucide.createIcons();
  }
  
  renderFormContent(main);
  return main;
}
