// js/components/CartDrawer.js

import { CartStore } from '../state/CartStore.js';
import { navigate } from '../state/AppState.js';
import { APP_VIEWS } from '../state/constants.js';
import { getIconSVG, formatCurrency } from '../utils/helpers.js';

export function closeCart() {
  CartStore.isCartOpen = false;
  CartStore.updateUI();
}

export function renderCartDrawer() {
  const root = document.getElementById('root');
  let drawer = root.querySelector('#cart-drawer');

  if (!CartStore.isCartOpen) {
    if (drawer) drawer.remove();
    return;
  }

  if (!drawer) {
    drawer = document.createElement('div');
    drawer.id = 'cart-drawer';
    drawer.className = 'fixed inset-0 z-50 flex justify-end';
    root.append(drawer);
  }

  const items = CartStore.items;
  const cartTotal = CartStore.cartTotal;
  const itemsCount = CartStore.itemsCount;

  const getCartItemsHTML = () => {
    if (items.length === 0) {
      return `
        <div class="h-full flex flex-col items-center justify-center text-stone-400 space-y-4">
          ${getIconSVG('ShoppingBag', 'icon-48 opacity-20')}
          <p class="text-center">Seu carrinho está vazio.</p>
          <button 
            id="close-cart-empty-btn"
            class="text-primary font-medium hover-underline"
          >
            Ver Cardápio
          </button>
        </div>
      `;
    }

    return items.map((item) => {
      const sizeLabel = item.size ? 
        (item.size === 'M' ? 'Médio' : item.size === 'G' ? 'Grande' : 'Família') : '';

      return `
        <div class="flex gap-4 p-3 border border-stone-100 rounded-xl bg-stone-50">
          <img 
            src="${item.product.imageUrl}" 
            alt="${item.product.name}" 
            class="w-16 h-16 object-cover rounded-md"
          />
          <div class="flex-1">
            <div class="flex justify-between items-start">
              <div>
                <h4 class="font-medium text-dark line-clamp-1">${item.product.name}</h4>
                ${item.size ? `
                  <span class="text-xs text-stone-500 font-medium bg-white border border-stone-200 px-1\.5 py-0\.5 rounded">
                    Tamanho: ${sizeLabel}
                  </span>
                ` : ''}
              </div>
              <button 
                data-cart-id="${item.cartId}"
                class="remove-item-btn text-stone-300 hover-text-red-500 transition-colors p-1"
                aria-label="Remover item"
              >
                ${getIconSVG('Trash2', 'icon-16')}
              </button>
            </div>
            
            <div class="flex items-center justify-between mt-3">
              <div class="flex items-center gap-3 bg-white border border-stone-200 rounded-lg px-2 py-1 shadow-sm">
                <button 
                  data-cart-id="${item.cartId}" data-delta="-1"
                  class="update-quantity-btn text-stone-400 hover-text-dark ${item.quantity <= 1 ? 'opacity-50' : ''}"
                  ${item.quantity <= 1 ? 'disabled' : ''}
                >
                  ${getIconSVG('Minus', 'icon-14')}
                </button>
                <span class="text-sm font-semibold w-4 text-center">${item.quantity}</span>
                <button 
                  data-cart-id="${item.cartId}" data-delta="1"
                  class="update-quantity-btn text-stone-400 hover-text-dark"
                >
                  ${getIconSVG('Plus', 'icon-14')}
                </button>
              </div>
              <span class="font-bold text-dark">${formatCurrency(item.totalPrice)}</span>
            </div>
          </div>
        </div>
      `;
    }).join('');
  }

  drawer.innerHTML = `
    <div 
      id="cart-backdrop"
      class="absolute inset-0"
      style="background: rgba(0,0,0,0.4); backdrop-filter: blur(4px);"
    ></div>

    <div class="relative w-full max-w-md bg-white h-full shadow-2xl flex flex-col animate-in slide-in-from-right duration-300">
      <div class="p-4 border-b border-stone-100 flex items-center justify-between bg-stone-50">
        <h2 class="font-serif text-xl font-bold text-dark flex items-center gap-2">
          ${getIconSVG('ShoppingBag', 'icon-20 text-primary')}
          Seu Pedido
        </h2>
        <button 
          id="close-cart-btn"
          class="p-2 text-stone-400 hover-text-dark transition-colors rounded-full"
          style="background: transparent; border: none; cursor: pointer;"
        >
          ${getIconSVG('X', 'icon-20')}
        </button>
      </div>

      <div class="flex-1 overflow-y-auto p-4 space-y-4">
        ${getCartItemsHTML()}
      </div>

      ${items.length > 0 ? `
        <div class="p-4 bg-white border-t border-stone-100 drawer-footer-shadow">
          <div class="flex justify-between items-center mb-4 text-lg">
            <span class="font-medium text-stone-600">Total</span>
            <span class="font-bold text-2xl text-dark">${formatCurrency(cartTotal)}</span>
          </div>
          <button 
            id="checkout-btn"
            class="w-full bg-primary hover-bg-red-700 text-white font-bold py-3\.5 rounded-xl shadow-lg shadow-red-200 transition-all active-scale-98 flex items-center justify-center gap-2"
          >
            Finalizar Pedido
            
          </button>
        </div>
      ` : ''}
    </div>
  `;

  // Adiciona Listeners
  drawer.querySelector('#cart-backdrop').addEventListener('click', closeCart);
  drawer.querySelector('#close-cart-btn')?.addEventListener('click', closeCart);
  drawer.querySelector('#close-cart-empty-btn')?.addEventListener('click', closeCart);

  drawer.querySelectorAll('.remove-item-btn').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const cartId = e.currentTarget.dataset.cartId;
      CartStore.removeItem(cartId);
    });
  });

  drawer.querySelectorAll('.update-quantity-btn').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const cartId = e.currentTarget.dataset.cartId;
      const delta = parseInt(e.currentTarget.dataset.delta);
      CartStore.updateQuantity(cartId, delta);
    });
  });

  drawer.querySelector('#checkout-btn')?.addEventListener('click', () => {
    closeCart();
    navigate(APP_VIEWS.CHECKOUT);
  });
  
  lucide.createIcons(); 
}
