// js/components/Menu.js

import { appState, setSelectedCategory } from '../state/AppState.js';
import { CATEGORIES, MENU_ITEMS } from '../state/constants.js';
import { renderProductCard } from './ProductCard.js';
import { renderReviewsSection } from './ReviewsSection.js'; 

export function renderMenu() {
  const main = document.createElement('main');
  main.className = 'py-8 space-y-12'; 

  const currentCategory = appState.selectedCategory;

  // 1. Hero Section (Full Width)
  const heroWrapper = document.createElement('div');
  heroWrapper.className = 'w-full';
  
  const heroHTML = `
    <div class="bg-dark p-8 md-p-12 relative overflow-hidden text-white shadow-2xl">
        <img 
            src="https://images.unsplash.com/photo-1590947132387-155cc02f3212?q=80&w=1920&auto=format&fit=crop" 
            alt="Pizza Hero" 
            class="absolute inset-0 w-full h-full object-cover mix-blend-overlay"
            style="opacity: 0.4;"
        />
        <div class="container mx-auto px-4">
            <div class="relative max-w-2xl" style="z-index: 10;">
                <h1 class="font-serif text-4xl md:text-6xl font-bold mb-4 leading-tight">
                    A Verdadeira Pizza <br/><span class="text-secondary">Artesanal</span>
                </h1>
                <p class="text-stone-200 text-lg mb-8 max-w-lg">
                    Ingredientes selecionados, massa de fermentação natural e o sabor inconfundível do forno a lenha.
                </p>
                <button 
                    id="scroll-to-menu-btn"
                    class="bg-primary hover-bg-red-700 text-white font-bold py-3 px-8 rounded-full transition-all hover-scale-105 shadow-lg"
                >
                    Ver Cardápio
                </button>
            </div>
        </div>
    </div>
  `;
  heroWrapper.innerHTML = heroHTML;

  // 2. Menu Content (Contained)
  const menuContent = document.createElement('div');
  menuContent.id = 'menu-sections-container';
  menuContent.className = 'container mx-auto px-4 space-y-12'; 
  
  // Renderiza APENAS a seção da categoria selecionada
  const categoryItems = MENU_ITEMS.filter(i => i.category === currentCategory);
    
  if (categoryItems.length > 0) {
    const section = document.createElement('section');
    section.id = currentCategory.toLowerCase();
    section.className = 'animate-in fade-in duration-300 scroll-mt-24'; 
    
    const title = currentCategory === CATEGORIES.PIZZA ? 'Pizzas Especiais' : 
                  currentCategory === CATEGORIES.DRINK ? 'Bebidas' : 'Sobremesas';
    const indicatorColorClass = currentCategory === CATEGORIES.PIZZA ? 'bg-secondary' : 'bg-stone-300';
    
    let gridClasses;
    if (currentCategory === CATEGORIES.PIZZA) {
      gridClasses = 'grid-cols-2 gap-6 product-cards-grid'; 
    } else {
      gridClasses = 'grid-cols-1 md-grid-cols-2 lg-grid-cols-4 gap-6 product-cards-grid';
    }
    
    section.innerHTML = `
      <h2 class="font-serif text-3xl font-bold text-dark mb-6 flex items-center gap-3">
        <span class="w-8 h-1 ${indicatorColorClass} rounded-full"></span>
        ${title}
      </h2>
      <div class="${gridClasses}">
      </div>
    `;
    
    const grid = section.querySelector('.product-cards-grid');
    categoryItems.forEach(item => {
      grid.appendChild(renderProductCard(item));
    });
    
    menuContent.appendChild(section);
  }

  main.appendChild(heroWrapper);
  main.appendChild(menuContent);
  
  // 3. Adiciona a Seção de Avaliações
  main.appendChild(renderReviewsSection()); 

  heroWrapper.querySelector('#scroll-to-menu-btn').addEventListener('click', () => {
    document.getElementById(CATEGORIES.PIZZA.toLowerCase())?.scrollIntoView({ behavior: 'smooth' });
    setSelectedCategory(CATEGORIES.PIZZA);
  });

  return main;
}
