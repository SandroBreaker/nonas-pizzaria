// js/components/ReviewsSection.js

import { getIconSVG, formatDate } from '../utils/helpers.js';

// Mock de dados de avaliações baseado na imagem fornecida
const REVIEWS = [
  {
    id: 1,
    author: "Matheus Freitas",
    rating: 5,
    date: "2024-03-20T10:00:00Z",
    text: "Fui no manhã de sábado (4/5/22) [A data foi ajustada para ser atual]. Tomamos um café da manhã excelente! Tudo muito fresquinho e bem saboroso, aquela cesta de padaria, o pão de queijo é muito bom. Meus pais vieram visitar e pediram para voltarmos, e vamos voltaremos com ctz. ... Mais",
    commentsCount: 17,
    photosCount: 2
  },
  {
    id: 2,
    author: "José Alberto",
    rating: 5,
    date: "2024-03-18T14:30:00Z",
    text: "Local muito bom na Zona Sul com atendimento com excelência. Recomendo o salmão com risoto de aspargos. Preços bons, mas a qualidade compensa! ... Mais",
    commentsCount: 4,
    photosCount: 6
  },
  {
    id: 3,
    author: "Boni Marc",
    rating: 5,
    date: "2024-03-17T09:15:00Z",
    text: "Adoro este lugar, frequento desde quando abriu, sempre um salão bem legal pra ir. ... Mais",
    commentsCount: 7,
    photosCount: 12
  },
  {
    id: 4,
    author: "Elizabeth Monari",
    rating: 5,
    date: "2024-03-15T18:00:00Z",
    text: "BONS PRODUTOS, INGREDIENTES FRESCOS / PREÇO ACESSÍVEL / ATENDIMENTO ÓTIMO. ... Mais",
    commentsCount: 2,
    photosCount: 2
  },
  {
    id: 5,
    author: "Angela Silva",
    rating: 4,
    date: "2024-03-14T11:00:00Z",
    text: "Maravilhosa tudo muito fresquinho e ótimo preço. ... Mais",
    commentsCount: 3,
    photosCount: 1
  },
  {
    id: 6,
    author: "Paloma Mascarenhas",
    rating: 4,
    date: "2024-03-12T08:45:00Z",
    text: "Atendimento rápido, um café da manhã. Cardápio com ótimas opções. Preço bom, mas tem que fazer um desejo no pedido em lanchonetes e dando. Previsão de preço, acabei de vir com uma dúvida incrível. Voltarei a frequentar 😊 ... Mais",
    commentsCount: 21,
    photosCount: 1
  },
  {
    id: 7,
    author: "Lanchonete e Pizzaria Boa Sorte (responsável)",
    rating: null, // Resposta do estabelecimento
    date: "2024-03-12T09:00:00Z",
    text: "Obrigado! 👏👏👏",
    isOwner: true,
  },
];

export function renderReviewsSection() {
  const section = document.createElement('section');
  section.id = 'reviews-section';
  section.className = 'container mx-auto px-4 py-12 space-y-8 bg-white rounded-3xl shadow-xl border border-stone-100 mt-12';

  section.innerHTML = `
    <h2 class="font-serif text-3xl font-bold text-dark mb-6 flex items-center gap-3">
      <span class="w-8 h-1 bg-primary rounded-full"></span>
      Avaliações dos Clientes
    </h2>
    <div class="space-y-6">
      ${REVIEWS.map(review => `
        <div class="border-b border-stone-100 pb-6 last:border-b-0">
          <div class="flex items-center gap-3 mb-2">
            <div class="w-10 h-10 rounded-full bg-stone-200 flex items-center justify-center text-dark font-semibold text-lg flex-shrink-0">
                ${review.isOwner ? getIconSVG('Pizza', 'icon-20 text-primary') : review.author.charAt(0)}
            </div>
            <div>
              <p class="font-semibold text-dark">${review.author} ${review.isOwner ? '<span class="text-sm text-stone-500">(Proprietário)</span>' : ''}</p>
              <div class="flex items-center text-sm text-stone-500">
                ${review.rating ? `
                  ${Array(review.rating).fill().map(() => getIconSVG('StarFill', 'icon-14 text-yellow-500')).join('')}
                  ${Array(5 - review.rating).fill().map(() => getIconSVG('Star', 'icon-14 text-stone-300')).join('')}
                ` : ''}
                <span class="ml-2">${formatDate(review.date)}</span>
              </div>
            </div>
          </div>
          <p class="text-stone-700 mb-3">${review.text}</p>
          <div class="flex items-center gap-4 text-sm text-stone-500">
            ${review.commentsCount ? `
                <span class="flex items-center gap-1">
                    ${getIconSVG('MessageSquare', 'icon-16')} ${review.commentsCount}
                </span>
            ` : ''}
            ${review.photosCount ? `
                <span class="flex items-center gap-1">
                    ${getIconSVG('Camera', 'icon-16')} ${review.photosCount}
                </span>
            ` : ''}
            <button class="text-primary hover-underline font-medium ml-auto">Ver Mais</button>
          </div>
        </div>
      `).join('')}
    </div>
  `;
  
  lucide.createIcons(); 
  return section;
}
