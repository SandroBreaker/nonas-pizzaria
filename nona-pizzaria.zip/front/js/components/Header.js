// js/components/Header.js

import { CartStore } from '../state/CartStore.js';
import { appState, navigate, setSelectedCategory } from '../state/AppState.js';
import { APP_VIEWS, CATEGORIES } from '../state/constants.js';
import { getIconSVG } from '../utils/helpers.js';

export function renderHeader() {
  const root = document.getElementById('root');
  let header = root.querySelector('header');

  if (!header) {
    header = document.createElement('header');
    header.className = "sticky-top-0 z-40 w-full bg-white backdrop-blur-sm border-b border-stone-100 shadow-sm transition-all duration-300";
    root.prepend(header);
  }

  const itemsCount = CartStore.itemsCount;
  const isMenu = appState.currentView === APP_VIEWS.MENU;
  const currentCategory = appState.selectedCategory; 

  header.innerHTML = `
    <div class="container h-16 flex items-center justify-between">
      <button 
        id="nav-to-menu-logo"
        class="flex items-center gap-2 group"
      >
        <div class="bg-primary p-1\.5 rounded-lg text-white transition-transform group-hover-rotate-12">
          ${getIconSVG('UtensilsCrossed', 'icon-24')}
        </div>
        <span class="font-serif text-xl font-bold tracking-tight text-dark">
          Nona's <span class="text-primary">Pizzeria</span>
        </span>
      </button>

      <nav class="flex items-center gap-4">
        ${!isMenu ? `
          <button 
            id="nav-to-menu-btn"
            class="text-stone-600 hover-text-primary font-medium text-sm md-hidden"
          >
            Voltar ao Menu
          </button>
        ` : ''}
        
        <button 
          id="open-cart-btn"
          class="relative p-2 text-stone-600 hover-text-primary transition-colors"
          aria-label="Abrir Carrinho"
        >
          ${getIconSVG('ShoppingCart', 'icon-24')}
          ${itemsCount > 0 ? `
            <span class="cart-count shadow-sm animate-in zoom-in">
              ${itemsCount}
            </span>
          ` : ''}
        </button>
      </nav>
    </div>

    ${isMenu ? `
        <div class="w-full bg-white border-b border-stone-100 shadow-sm">
            <div class="container flex justify-start items-center gap-3 overflow-x-auto whitespace-nowrap py-2">
                ${Object.values(CATEGORIES).map(category => {
                    const isActive = category === currentCategory;
                    const label = category.charAt(0) + category.slice(1).toLowerCase();
                    return `
                        <button 
                            data-category="${category}"
                            class="category-nav-btn px-4 py-1\.5 rounded-full text-sm font-semibold transition-colors flex-shrink-0 ${
                                isActive 
                                    ? 'bg-primary text-white shadow-md' 
                                    : 'bg-stone-100 text-stone-600 hover-bg-stone-200'
                            }"
                        >
                            ${label}
                        </button>
                    `;
                }).join('')}
            </div>
        </div>
    ` : ''}
  `;

  // Adiciona listeners
  header.querySelector('#nav-to-menu-logo').addEventListener('click', () => navigate(APP_VIEWS.MENU));
  const navBtn = header.querySelector('#nav-to-menu-btn');
  if(navBtn) navBtn.addEventListener('click', () => navigate(APP_VIEWS.MENU));
  
  header.querySelector('#open-cart-btn').addEventListener('click', () => {
    CartStore.isCartOpen = true;
    CartStore.updateUI();
  });

  if (isMenu) {
      header.querySelectorAll('.category-nav-btn').forEach(btn => {
          btn.addEventListener('click', (e) => {
              const category = e.currentTarget.dataset.category;
              setSelectedCategory(category);
          });
      });
  }

  lucide.createIcons(); 
}
