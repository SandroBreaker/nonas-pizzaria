// js/components/ProductCard.js

import { CartStore } from '../state/CartStore.js';
import { getIconSVG, formatCurrency } from '../utils/helpers.js';
import { CATEGORIES, PIZZA_SIZES } from '../state/constants.js';

export function renderProductCard(product) {
  const isPizza = product.category === CATEGORIES.PIZZA;
  let selectedSize = isPizza ? PIZZA_SIZES.G : undefined;
  
  const card = document.createElement('div');
  card.className = "bg-white rounded-xl shadow-sm border border-stone-100 overflow-hidden flex flex-col hover-shadow-md transition-shadow duration-300";

  const renderPriceAndActions = (currentPrice, size) => {
    return `
        <div class="flex items-center justify-between pt-2 border-t border-stone-100">
            <span class="font-bold text-lg text-dark">
                ${formatCurrency(currentPrice)}
            </span>
            <button 
                data-product-id="${product.id}" 
                data-size="${size || ''}"
                class="add-to-cart-btn bg-primary hover-bg-red-700 text-white p-2 rounded-full shadow-sm hover-shadow-md transition-all active-scale-95"
                aria-label="Adicionar ao Carrinho"
            >
                ${getIconSVG('Plus', 'icon-20')}
            </button>
        </div>
    `;
  };

  const getPizzaSizeButtons = () => {
    return `
      <div class="flex bg-stone-100 rounded-lg p-1">
        ${Object.values(PIZZA_SIZES).map(size => {
          const label = size === 'M' ? 'Média' : size === 'G' ? 'Grande' : 'Família';
          const isActive = size === selectedSize;
          return `
            <button
              data-size="${size}"
              data-product-id="${product.id}"
              class="size-button flex-1 text-xs font-medium py-1\.5 rounded-md transition-all ${
                isActive 
                  ? 'bg-white text-primary shadow-sm' 
                  : 'text-stone-500 hover-text-stone-700'
              }"
            >
              ${label}
            </button>
          `;
        }).join('')}
      </div>
    `;
  }

  const initialPrice = product.priceModifiers ? product.priceModifiers[selectedSize] : product.basePrice;

  card.innerHTML = `
      <div class="relative h-48 overflow-hidden group">
          <img 
            src="${product.imageUrl}" 
            alt="${product.name}" 
            class="w-full h-full object-cover transition-transform duration-500 group-hover-scale-110"
            loading="lazy"
          />
          <div class="absolute inset-0" style="background: linear-gradient(to top, rgba(0,0,0,0.5), transparent); opacity: 0.6;"></div>
          <div class="absolute bottom-3 left-3 text-white">
              <span class="text-xs font-bold bg-secondary px-2 py-0\.5 rounded-full uppercase tracking-wider">
                  ${product.category}
              </span>
          </div>
      </div>
      
      <div class="p-4 flex-1 flex flex-col">
          <h3 class="font-serif text-lg font-bold text-dark mb-1">${product.name}</h3>
          <p class="text-stone-500 text-sm mb-4 flex-1 line-clamp-3">
              ${product.description}
          </p>

          <div class="mt-auto space-y-3 product-actions">
              ${isPizza ? getPizzaSizeButtons() : ''}
              <div class="price-and-actions">
                ${renderPriceAndActions(initialPrice, selectedSize)}
              </div>
          </div>
      </div>
  `;

  // --- Lógica de Interação ---
  const priceAndActionsContainer = card.querySelector('.price-and-actions');

  const updatePriceAndListeners = (size) => {
        const currentPrice = product.priceModifiers ? product.priceModifiers[size] : product.basePrice;
        priceAndActionsContainer.innerHTML = renderPriceAndActions(currentPrice, size);
        
        const newAddToCartBtn = card.querySelector('.add-to-cart-btn');
        if (newAddToCartBtn) {
            newAddToCartBtn.addEventListener('click', () => CartStore.addItem(product, size));
        }
  };

  if (isPizza) {
    const sizeButtons = card.querySelectorAll('.size-button');
    sizeButtons.forEach(button => {
      button.addEventListener('click', (e) => {
        const newSize = e.target.dataset.size;
        selectedSize = newSize;

        sizeButtons.forEach(b => {
          b.classList.remove('bg-white', 'text-primary', 'shadow-sm');
          b.classList.add('text-stone-500', 'hover-text-stone-700');
        });
        e.target.classList.add('bg-white', 'text-primary', 'shadow-sm');
        e.target.classList.remove('text-stone-500', 'hover-text-stone-700');

        updatePriceAndListeners(newSize);
      });
    });
  }

  updatePriceAndListeners(selectedSize);

  return card;
}
