// js/components/PixPayment.js

import { CartStore } from '../state/CartStore.js';
import { appState, navigate } from '../state/AppState.js'; // IMPORT ATUALIZADO
import { APP_VIEWS, OFFER_HASH_DEFAULT } from '../state/constants.js';
import { getIconSVG, formatCurrency } from '../utils/helpers.js';
import { executeInvictusApi } from '../utils/invictusPayApi.js'; 


export function renderPixPayment() {
  let finalTotal = CartStore.cartTotal;
  let pixData = null;
  let loading = true;
  let error = null;
  let copied = false;
  
  // NOVO: Pega os dados reais do cliente do AppState
  const customerData = appState.customerData; 

  // Limpa o carrinho no início da tela de pagamento
  CartStore.clearCart(); 

  const main = document.createElement('main');
  main.className = 'container mx-auto';
  
  const handleCopy = async (btn) => {
    try {
      const code = pixData?.pix?.pix_qr_code;
      if (!code) throw new Error("Código PIX não disponível.");
      
      await navigator.clipboard.writeText(code);
      copied = true;
      btn.innerHTML = `${getIconSVG('Check', 'icon-18')} Copiado!`;
      btn.classList.remove('bg-stone-800', 'hover-bg-black');
      btn.classList.add('bg-green-500');
      
      // O re-render completo irá resetar o estado do botão após 3s
      setTimeout(() => {
        copied = false;
        renderContent(main); 
      }, 3000);

    } catch (err) {
      console.error('Failed to copy', err);
    }
    // Força o primeiro re-render para mostrar o estado "Copiado!"
    renderContent(main); 
  };
  
  const renderContent = (container) => {
    
    container.innerHTML = `
      <div class="max-w-xl mx-auto py-12 px-4 animate-in zoom-in-95 duration-500">
        <div class="bg-white rounded-3xl shadow-2xl p-8 text-t-8 ${error ? 'border-red-500' : 'border-green-500'}">
          ${loading ? `
            <div class="flex flex-col items-center justify-center space-y-4">
                ${getIconSVG('LoaderCircle', 'icon-64 text-primary animate-spin')}
                <h2 class="text-2xl font-serif font-bold text-dark">Gerando PIX...</h2>
                <p class="text-stone-500">Aguarde enquanto processamos sua transação segura.</p>
            </div>
          ` : error ? `
            <div class="flex flex-col items-center justify-center space-y-4">
                ${getIconSVG('XCircle', 'icon-64 text-red-500')}
                <h2 class="text-2xl font-serif font-bold text-dark">Erro no Pagamento</h2>
                <p class="text-stone-500">${error}</p>
                <button 
                  id="reset-app-btn"
                  class="text-primary hover-text-dark font-medium flex items-center justify-center gap-2 mx-auto transition-colors mt-4"
                >
                  ${getIconSVG('Home', 'icon-18')}
                  Voltar para o Início
                </button>
            </div>
          ` : `
            <div class="mb-6 flex justify-center">
              <div class="bg-green-100 p-4 rounded-full">
                ${getIconSVG('CheckCircle2', 'icon-64 text-green-600')}
              </div>
            </div>
            
            <h2 class="text-3xl font-serif font-bold text-dark mb-2">Pedido Recebido!</h2>
            <p class="text-stone-500 mb-8">Agora só falta o pagamento para prepararmos sua pizza.</p>

            <div class="bg-stone-50 rounded-xl p-6 mb-8 border border-stone-100">
              <p class="text-sm font-bold text-stone-400 uppercase tracking-wider mb-1">Valor Total</p>
              <p class="text-4xl font-bold text-dark mb-6">${formatCurrency(finalTotal)}</p>

              <div class="space-y-4">
                ${pixData?.pix?.qr_code_base64 ? `
                    <div class="flex justify-center mb-4">
                        <img src="data:image/png;base64,${pixData.pix.qr_code_base64}" alt="QR Code PIX" class="w-32 h-32 border border-stone-200 p-1 rounded-lg">
                    </div>
                ` : ''}

                <div class="text-left">
                  <label class="text-xs font-semibold text-stone-500 uppercase ml-1">Pix Copia e Cola</label>
                  <div class="flex gap-2 mt-1">
                    <input 
                      readOnly 
                      value="${pixData?.pix?.pix_qr_code || ''}" 
                      id="pix-code-input"
                      class="w-full bg-white border border-stone-200 rounded-lg px-3 py-2 text-sm text-stone-400 truncate"
                    />
                    <button 
                      id="copy-pix-btn"
                      class="flex-shrink-0 px-4 py-2 rounded-lg font-bold transition-all flex items-center gap-2 ${
                        copied 
                          ? 'bg-green-500 text-white' 
                          : 'bg-stone-800 text-white hover-bg-black'
                      }"
                    >
                      ${copied ? getIconSVG('Check', 'icon-18') : getIconSVG('Copy', 'icon-18')}
                      ${copied ? 'Copiado!' : 'Copiar'}
                    </button>
                  </div>
                </div>
                
                <div class="text-xs text-stone-400 bg-white p-3 rounded-lg border border-dashed border-stone-300">
                  <p>1. Abra o app do seu banco</p>
                  <p>2. Escolha pagar via PIX > Copia e Cola</p>
                  <p>3. Cole o código acima e confirme</p>
                  <p class="mt-2 text-stone-500">Protocolo: ${pixData?.hash || 'N/A'}</p>
                </div>
              </div>
            </div>

            <button 
              id="reset-app-btn"
              class="text-stone-500 hover-text-primary font-medium flex items-center justify-center gap-2 mx-auto transition-colors"
            >
              ${getIconSVG('Home', 'icon-18')}
              Voltar para o Início
            </button>
          `}
        </div>
      </div>
    `;
    
    // Adiciona Listeners
    if (!loading && !error) {
        container.querySelector('#copy-pix-btn')?.addEventListener('click', (e) => handleCopy(e.currentTarget));
    }
    container.querySelector('#reset-app-btn')?.addEventListener('click', () => navigate(APP_VIEWS.MENU));
    
    if (copied) {
        const input = container.querySelector('#pix-code-input');
        if (input) {
             input.select();
             input.setSelectionRange(0, 99999);
        }
    }

    lucide.createIcons();
  };

  // --- Lógica Assíncrona de Geração do PIX ---
  const generatePix = async () => {
    // RENDER 1: Loading
    renderContent(main); 

    if (finalTotal <= 0) {
        error = "O total do pedido deve ser maior que zero. Adicione itens ao carrinho.";
        loading = false;
        renderContent(main);
        return;
    }

    if (!customerData) {
        error = "Dados do cliente não foram encontrados. Volte ao Checkout e preencha o formulário.";
        loading = false;
        renderContent(main);
        return;
    }
    
    // CONVERSÃO E VALIDAÇÃO DE DADOS DO FORMULÁRIO PARA O FORMATO DA API INVICTUS PAY
    // Usa os dados do formulário, limpando máscaras.
    const invictusCustomerData = {
        name: customerData.fullName,
        document: customerData.cpf.replace(/\D/g, ''),
        phone_number: customerData.phone.replace(/\D/g, ''),
        email: customerData.email,
        zip_code: customerData.address.zipCode.replace(/\D/g, ''),
        number: customerData.address.number,
        street_name: customerData.address.street,
        neighborhood: customerData.address.neighborhood,
        // Usando defaults caso CEP não tenha sido preenchido
        city: "Sao Paulo", 
        state: "SP", 
    };

    const valorEmCentavos = Math.round(finalTotal * 100);

    const payload = {
        "amount": valorEmCentavos, 
        "offer_hash": OFFER_HASH_DEFAULT, 
        "payment_method": "pix", 
        "customer": invictusCustomerData, // USANDO DADOS REAIS
        "cart": [{
            "product_hash": OFFER_HASH_DEFAULT,
            "title": "Pedido Nona's Pizzeria",
            "price": valorEmCentavos,
            "quantity": 1,
            "operation_type": 1, 
            "tangible": true
        }],
        "installments": 1,
        "expire_in_days": 1,
        "transaction_origin": "api"
    };

    const result = await executeInvictusApi(payload);

    if (result.success) {
        pixData = result.data;
    } else {
        error = result.error;
    }

    loading = false;
    // RENDER 2: Success or Error
    renderContent(main); 
  };
  
  // Inicia a geração do PIX
  generatePix();

  return main;
}
